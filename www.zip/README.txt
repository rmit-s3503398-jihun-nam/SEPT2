Team Members and Contribution rates

Jihun Nam s3503398 25%
Sean Lee Jin Xiang s3301214 25% 
Victor Soliman s3448362 25%
Labib Ali Syed s3465920 25%

Tutor A Homy Ash
Wednesday 17:30	19:30 056.04.089 

Note - Our team made a web spider and generated a json file to pull data from BOM site in a easy way.
original source file is included.(node js).
 

Please open home.shtml in Documentation folder for more details about the app.
 

