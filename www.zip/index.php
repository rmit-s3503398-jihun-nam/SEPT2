<?php

  /*
  *	 Bootstraping initial settings 
  */
  
  require_once("lib/Session.php");
  require_once("lib/BaseView.php");
  require_once("lib/BaseController.php");
  require_once("Helper.php");
  require_once("Init.php");


  $Init = new Init();